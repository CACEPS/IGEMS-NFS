"""Population-weighted inequality indices on per-capita entitlements.

Computes Gini, Theil, Atkinson (epsilon=1), Palma ratio, and max:min for
each allocation rule. All indices are population weighted. The Palma
ratio is the entitlement share of the top 10 percent of world population
over the share of the bottom 40 percent, ranked by per-capita
entitlement. Backs main-text Table 2.
"""

import numpy as np
import pandas as pd
from igems_model import run, MECHANISMS


def wgini(x, w):
    idx = np.argsort(x)
    x = np.asarray(x, float)[idx]
    w = np.asarray(w, float)[idx]
    xw = x * w
    S = xw.sum()
    cumx = np.cumsum(xw)
    B = np.sum(w * (cumx - xw / 2)) / (S * w.sum())
    return 1 - 2 * B


def theil(x, w):
    x = np.asarray(x, float)
    w = np.asarray(w, float) / np.sum(w)
    mu = np.sum(w * x)
    return float(np.sum(w * (x / mu) * np.log(x / mu)))


def atkinson1(x, w):
    x = np.asarray(x, float)
    w = np.asarray(w, float) / np.sum(w)
    mu = np.sum(w * x)
    geo = np.exp(np.sum(w * np.log(x)))
    return float(1 - geo / mu)


def palma(x, w):
    idx = np.argsort(x)
    x = np.asarray(x, float)[idx]
    w = np.asarray(w, float)[idx]
    cw = np.cumsum(w) / np.sum(w)
    share_b, prev = 0.0, 0.0
    for xi, c in zip(x, cw):
        take = min(c, 0.40) - prev
        if take > 0:
            share_b += xi * take
        prev = c
        if c >= 0.40:
            break
    share_t, prev = 0.0, 0.0
    for xi, c in zip(x, cw):
        lo = max(prev, 0.90)
        if c > lo:
            share_t += xi * (c - lo)
        prev = c
    return float(share_t / share_b)


def main():
    res, _ = run()
    pop = res["Population_millions"].values
    rows = []
    for m in MECHANISMS:
        pc = res[f"{m}_allocation_Gt"].values / pop
        rows.append(dict(Rule=m,
                         Gini=round(wgini(pc, pop), 3),
                         Theil=round(theil(pc, pop), 3),
                         Atkinson_e1=round(atkinson1(pc, pop), 3),
                         Palma=round(palma(pc, pop), 2),
                         Max_to_min=round(pc.max() / pc.min(), 2)))
    df = pd.DataFrame(rows)
    df.to_csv("../outputs/inequality_indices.csv", index=False)
    print(df.to_string(index=False))
    for col in ["Gini", "Theil", "Atkinson_e1", "Palma", "Max_to_min"]:
        order = tuple(df.sort_values(col)["Rule"])
        print(f"{col:12s} most-equal-first: {order}")


if __name__ == "__main__":
    main()
