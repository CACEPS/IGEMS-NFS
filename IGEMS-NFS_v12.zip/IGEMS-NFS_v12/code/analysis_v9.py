"""Workstreams 2, 4, 5: pathways, switching values, extended Monte Carlo, bargain search."""
import pandas as pd, numpy as np, os, json
from scipy.special import expit
from igems_v9 import load_baseline, run, bloc_summary, shares, BASE
from region_map import HIGH, LOW, ORDER, NAMES
O=os.path.join(os.path.dirname(__file__),"..","outputs"); D=os.path.join(os.path.dirname(__file__),"..","data")
df=load_baseline(f"{O}/baseline_v9.csv"); E0=df.Current_emissions_Gt.values; pop=df.Population_millions.values
fs=pd.read_csv(f"{O}/frontier_summary.csv",index_col=0).iloc[:,0]
d_obs=float(fs["p95_decl"]); d_hi=float(fs["p95_incl_crisis"])
r_obs=-np.log(1-d_obs); r_hi=-np.log(1-d_hi)
H=df.Region_code.isin(HIGH).values; L=df.Region_code.isin(LOW).values
out={}

# ---------- WS2: BAU growth and surplus pathways ----------
ow=pd.read_csv(f"{D}/owid-co2-data.csv")
from region_map import region_of
ow=ow[ow.iso_code.notna()]; ow["region"]=ow.iso_code.map(region_of)
g={}
for r in ORDER:
    s=ow[ow.region==r].groupby("year").co2.sum()
    g[r]=(s[2024]/s[2014])**(1/10)-1
out["bau_growth_2014_2024"]={k:round(v*100,2) for k,v in g.items()}
def bau_cum(e0,gr,T=50): 
    gg=np.log(1+gr); return e0*T if abs(gg)<1e-9 else e0*(np.exp(gg*T)-1)/gg
path_rows=[]
for B in [130,250,500,650]:
    S=shares(df,BASE)
    for rule,s in S.items():
        for j,c in enumerate(ORDER):
            Bi=s[j]*B; r=E0[j]/Bi; row=dict(B_total=B,Rule=rule,Region=NAMES[c],B_i_Gt=Bi,
                annual_decline_pct=(1-np.exp(-r))*100, netzero_linear=2024+2*Bi/E0[j],
                surplus=False, peak_year=np.nan, post_peak_decline_pct=np.nan)
            gg=np.log(1+g[c])
            if g[c]>0 and Bi>bau_cum(E0[j],g[c]):
                # peak-then-decline at the observed frontier
                x=(Bi/E0[j]+1/gg)/(1/gg+1/r_obs); T=np.log(x)/gg
                row.update(surplus=True,peak_year=2024+T,post_peak_decline_pct=d_obs*100)
            path_rows.append(row)
P=pd.DataFrame(path_rows); P.to_csv(f"{O}/pathways_v9.csv",index=False)

# ---------- helpers ----------
def bloc_acc(rates, rstar, k, w_idx):
    a=expit(k*(rstar-rates)/rstar); return (a*pop*w_idx).sum()/(pop*w_idx).sum()
def rates_for(s,B): return E0/(s*B)
def clears(S,B,rstar,k,tau):
    best=None
    for rule,s in S.items():
        rt=rates_for(s,B); he=bloc_acc(rt,rstar,k,H); li=bloc_acc(rt,rstar,k,L)
        if he>tau and li>tau: best=rule; break
    return best

# ---------- WS4: switching values (base structural parameters) ----------
S=shares(df,BASE); sw={}
for B in [130,250,500,650]:
    # frontier switching value at k=8, tau=0.5
    rs_grid=np.linspace(0.005,0.60,6000); hit=None
    for rs in rs_grid:
        c=clears(S,B,rs,8,0.5)
        if c: hit=(rs,c); break
    # tau switching value at observed frontier
    best_min=max(min(bloc_acc(rates_for(s,B),r_obs,8,H),bloc_acc(rates_for(s,B),r_obs,8,L)) for s in S.values())
    sw[B]=dict(global_required_annual_pct=(1-np.exp(-E0.sum()/B))*100,
               rstar_switch_annual_pct=(1-np.exp(-hit[0]))*100 if hit else None,
               rule_that_clears_first=hit[1] if hit else None,
               multiple_of_observed=((1-np.exp(-hit[0]))/d_obs) if hit else None,
               tau_switch=best_min)
    # k switching at observed frontier
    ks=[k for k in np.linspace(0.25,16,64) if clears(S,B,r_obs,k,0.5)]
    sw[B]["k_values_clearing"]=(min(ks),max(ks)) if ks else None
out["switching"]=sw

# ---------- WS4: extended Monte Carlo (1,000 draws) ----------
rng=np.random.default_rng(42); N=1000; mc=[]
for i in range(N):
    p=dict(BASE, hist_resp_coeff=rng.uniform(0.2,0.6), income_scale=rng.uniform(0.85,1.15),
           forest_multiplier=rng.uniform(1.5,2.5), hybrid_weights=tuple(rng.dirichlet([1,1,1])))
    tau=rng.uniform(0.3,0.7); k=rng.uniform(4,16); rs=-np.log(1-rng.uniform(d_obs,d_hi))
    Sd=shares(df,p)
    for B in (250,500):
        row=dict(draw=i,B=B,tau=tau,k=k,rstar_annual=(1-np.exp(-rs)))
        for rule,s in Sd.items():
            rt=rates_for(s,B)
            row[f"{rule}_adh"]=(rt<=rs).mean()
            row[f"{rule}_HE"]=bloc_acc(rt,rs,k,H); row[f"{rule}_LI"]=bloc_acc(rt,rs,k,L)
            row[f"{rule}_both"]=(row[f"{rule}_HE"]>tau) and (row[f"{rule}_LI"]>tau)
        mc.append(row)
MC=pd.DataFrame(mc); MC.to_csv(f"{O}/monte_carlo_v9.csv",index=False)
mcs={}
for B in (250,500):
    m=MC[MC.B==B]; anyc=m[[f"{r}_both" for r in ["Market","Equity","Capacity","Hybrid"]]].any(axis=1)
    mcs[B]=dict(any_rule_clears_share=float(anyc.mean()),
        by_rule={r:float(m[f"{r}_both"].mean()) for r in ["Market","Equity","Capacity","Hybrid"]},
        min_rstar_in_clearing_draws=float(m[anyc].rstar_annual.min()) if anyc.any() else None,
        market_adherence_all_or_nothing=bool(set(np.round(m.Market_adh,6))<= {0.0,1.0}),
        market_last_on_adherence=float((m.Market_adh<=m[["Equity_adh","Capacity_adh","Hybrid_adh"]].min(axis=1)).mean()),
        market_first_on_adherence=float((m.Market_adh>=m[["Equity_adh","Capacity_adh","Hybrid_adh"]].max(axis=1)).mean()),
        hybrid_adh_mean=float(m.Hybrid_adh.mean()))
out["monte_carlo"]=mcs

# ---------- WS5: bargain search ----------
def bargain(B, rs, k=8, tau=0.5, v=1.0, p=100.0, thetas=np.linspace(0,1.6,1601)):
    eq=S["Equity"]*B; mk=S["Market"]*B; res=[]
    for th in thetas:
        A=eq+th*(mk-eq)
        if (A<=0).any(): break
        G=np.clip((A-eq)*H,0,None).sum()          # tonnes HE receive above equity
        loss=np.clip((eq-A)*L,0,None)              # LI physical tonnes below equity
        comp=np.zeros_like(A)
        if loss.sum()>0: comp=v*G*loss/loss.sum()
        Aeff=A+comp
        he=bloc_acc(E0/A,rs,k,H); li=bloc_acc(E0/Aeff,rs,k,L)
        res.append(dict(theta=th,HE=he,LI=li,ok=(he>tau and li>tau),transfer_cum_bn=p*G))
    R=pd.DataFrame(res); ok=R[R.ok]
    return R, (ok.iloc[0] if len(ok) else None)
def annual_transfer(B, th, p=100.0, years=range(2025,2051)):
    eq=S["Equity"]*B; A=eq+th*(S["Market"]*B-eq); r_eq=E0/eq; r_A=E0/A; tot=[]
    for y in years:
        t0,t1=y-2025,y-2024
        f=lambda r: E0*(np.exp(-r*t0)-np.exp(-r*t1))/r
        tot.append(p*np.clip((f(r_A)-f(r_eq))*H,0,None).sum())
    return float(np.mean(tot)), float(np.max(tot))
bg={}
for B in [250,500,650]:
    for lab,rs in [("observed",r_obs),("crisis_upper",r_hi)]:
        R,first=bargain(B,rs)
        hemax=R.HE.max()
        entry=dict(feasible=first is not None, HE_max=float(hemax), theta_max_tested=float(R.theta.max()))
        if first is not None:
            m,pk=annual_transfer(B,first.theta)
            entry.update(theta_min=float(first.theta),HE=float(first.HE),LI=float(first.LI),
                         transfer_cum_USDbn_at100=float(first.transfer_cum_bn),
                         transfer_avg_2025_2050_USDbn_per_yr=m, transfer_peak_USDbn_per_yr=pk)
        bg[f"B{B}_{lab}"]=entry
    # minimum frontier at which any bargain exists
    for rs in np.linspace(r_obs,0.4,700):
        R,first=bargain(B,rs,thetas=np.linspace(0,1.6,321))
        if first is not None:
            bg[f"B{B}_min_frontier_for_bargain_annual_pct"]=(1-np.exp(-rs))*100; break
# valuation discount sensitivity at the upper frontier, B=500
vs={}
for v in [1.0,0.75,0.5,0.25]:
    R,first=bargain(500,r_hi,v=v); vs[v]=None if first is None else float(first.theta)
bg["B500_crisis_upper_theta_min_by_valuation"]=vs
# HE physical need at the frontier
bg["HE_cumulative_need_at_observed_frontier_Gt"]=float((E0*H).sum()/r_obs)
bg["HE_cumulative_need_at_upper_frontier_Gt"]=float((E0*H).sum()/r_hi)
out["bargain"]=bg
out["frontiers"]=dict(observed_annual_pct=d_obs*100, upper_crisis_annual_pct=d_hi*100)
# intro overshoot check: uniform 2.5%/yr from 37.4 Gt over 2025-2074
out["uniform_2p5_cum_50yr_Gt"]=float(E0.sum()*sum(0.975**t for t in range(1,51)))
json.dump(out,open(f"{O}/results_v9.json","w"),indent=1,default=float)
print(json.dumps(out,indent=1,default=float))
