"""Rebuild the nine-region baseline from public data (Workstream 1.3).
Scope: territorial fossil CO2 incl. cement (GCP via OWID), excluding land use and bunkers."""
import pandas as pd, numpy as np, os
from region_map import region_of, ORDER, NAMES, BLOC
D=os.path.join(os.path.dirname(__file__),"..","data")
owid=pd.read_csv(f"{D}/owid-co2-data.csv")
owid=owid[owid.iso_code.notna() & ~owid.iso_code.str.startswith("OWID_",na=False) | (owid.iso_code=="OWID_KOS")]
gdp=pd.read_csv(f"{D}/wb_gdp_current_usd.csv")
gdp=gdp[gdp.Year==2023].set_index("Country Code")["Value"]
# external fills for economies absent from WDI (flagged, US$ current 2023, IMF WEO approximations)
FILL={"TWN":7.56e11,"VEN":0.92e11,"PRK":0.25e11,"ERI":0.02e11,"SYR":0.20e11,"YEM":0.19e11}
def build(year=2024):
    y=owid[owid.year==year].copy()
    y["region"]=y.iso_code.map(region_of)
    unmapped=y[y.region.isna() & (y.co2.fillna(0)>0.5)][["country","iso_code","co2"]]
    y=y[y.region.notna()]
    y["gdp23"]=y.iso_code.map(lambda i: gdp.get(i, FILL.get(i, np.nan)))
    agg=y.groupby("region").agg(co2=("co2","sum"),pop=("population","sum"),gdp=("gdp23","sum"),
                                cum=("cumulative_co2","sum"),n=("iso_code","count"))
    agg=agg.loc[ORDER]
    out=pd.DataFrame({"Region":[NAMES[r] for r in ORDER],"Region_code":ORDER,
        "Current_emissions_Gt":agg.co2.values/1000,"Population_millions":agg["pop"].values/1e6,
        "GDP_trillions_USD":agg.gdp.values/1e12,"Historical_emissions_Gt":agg.cum.values/1000,
        "Countries":agg.n.values,"Negotiating_bloc":[BLOC[r] for r in ORDER]})
    return out, unmapped, y
if __name__=="__main__":
    out,un,y=build()
    O=os.path.join(os.path.dirname(__file__),"..","outputs")
    out.to_csv(f"{O}/baseline_v9.csv",index=False)
    print(out.round(3).to_string()); print("TOTAL",out[["Current_emissions_Gt","Population_millions","GDP_trillions_USD","Historical_emissions_Gt"]].sum().round(2).to_dict())
    print("Unmapped >0.5 Mt:\n",un.to_string())
    w=owid[(owid.country=="World")] if False else None
