"""Workstream 3.1: observed decline-rate frontier from national territorial CO2 (GCP via OWID).
Rolling 10-year compound annual decline, countries above 10 Mt at window start, windows 1970-2024."""
import pandas as pd, numpy as np, os
D=os.path.join(os.path.dirname(__file__),"..","data"); O=os.path.join(os.path.dirname(__file__),"..","outputs")
d=pd.read_csv(f"{D}/owid-co2-data.csv")
d=d[d.iso_code.notna() & ~d.iso_code.str.startswith("OWID_",na=False)][["country","iso_code","year","co2"]]
TRANSITION=set("RUS UKR BLR MDA ARM AZE GEO KAZ KGZ TJK TKM UZB EST LVA LTU BGR CZE SVK HUN POL ROU SVN HRV BIH SRB MNE MKD ALB DEU".split())
COLLAPSE={"SYR":(2011,2100),"YEM":(2014,2100),"LBY":(2011,2100),"VEN":(2013,2100),"UKR":(2014,2100),
          "IRQ":(1990,2003),"ZWE":(2000,2009),"PRK":(1970,2100),"KWT":(1990,1992),"CUB":(1990,1995),"AFG":(1979,2002),"LBN":(2019,2100)}
W=10; rows=[]
for iso,g in d.groupby("iso_code"):
    s=g.set_index("year").co2.dropna()
    for y0 in range(1970,2024-W+1):
        y1=y0+W
        if y0 not in s or y1 not in s or s[y0]<10 or s[y1]<=0: continue
        rate=1-(s[y1]/s[y0])**(1/W)  # annual compound decline (positive = decline)
        # smoothed endpoints: 3-yr means (centred where possible)
        a=s.loc[y0-1:y0+1].mean(); b=s.loc[y1-1:min(y1+1,2024)].mean()
        rate_s=1-(b/a)**(1/W)
        flag="none"
        if iso in TRANSITION and y0<=1998 and y1>=1989: flag="post-Soviet transition"
        if iso in COLLAPSE:
            c0,c1=COLLAPSE[iso]
            if y0<=c1 and y1>=c0: flag="conflict/collapse"
        if y1==2020 and flag=="none": flag="pandemic endpoint"
        rows.append(dict(iso=iso,country=g.country.iloc[0],start=y0,end=y1,E_start_Mt=s[y0],
                         decline=rate,decline_smoothed=rate_s,flag=flag))
w=pd.DataFrame(rows); w.to_csv(f"{O}/frontier_windows.csv",index=False)
clean=w[w.flag=="none"]; dec=clean[clean.decline>0]
def q(x,p): return float(np.percentile(x,p))
summ=dict(windows=len(w),clean_windows=len(clean),clean_declining=len(dec),
  countries_declining=dec.iso.nunique(),
  p50_decl=q(dec.decline,50),p90_decl=q(dec.decline,90),p95_decl=q(dec.decline,95),p99_decl=q(dec.decline,99),
  max_clean=float(dec.decline.max()),
  p95_all_clean=q(clean.decline,95),
  p95_decl_smoothed=q(clean[clean.decline_smoothed>0].decline_smoothed,95),
  p95_decl_large100=q(dec[dec.E_start_Mt>=100].decline,95), max_large100=float(dec[dec.E_start_Mt>=100].decline.max()),
  p95_incl_crisis=q(w[w.decline>0].decline,95), max_incl_crisis=float(w.decline.max()))
pd.Series(summ).to_csv(f"{O}/frontier_summary.csv")
for k,v in summ.items(): print(f"{k:24s} {v:.4f}" if isinstance(v,float) else f"{k:24s} {v}")
print(dec.sort_values("decline",ascending=False).drop_duplicates("iso").head(12)[["country","start","end","E_start_Mt","decline"]].to_string())
L=dec[dec.E_start_Mt>=100].sort_values("decline",ascending=False).drop_duplicates("iso").head(10)
print(L[["country","start","end","E_start_Mt","decline"]].to_string())
