"""Tables for the v9 manuscript and supplement (inequality, validation, blocs, QMV, bargain curve, fund)."""
import pandas as pd, numpy as np, os, json
from scipy.special import expit
from scipy.stats import spearmanr
from igems_v9 import load_baseline, shares, BASE
from region_map import HIGH, LOW, ORDER, NAMES
O=os.path.join(os.path.dirname(__file__),"..","outputs")
df=load_baseline(f"{O}/baseline_v9.csv"); E0=df.Current_emissions_Gt.values; pop=df.Population_millions.values
Y=df.GDP_trillions_USD.values; Hh=df.Historical_emissions_Gt.values
H=df.Region_code.isin(HIGH).values; L=df.Region_code.isin(LOW).values
R=json.load(open(f"{O}/results_v9.json")); d_obs=R["frontiers"]["observed_annual_pct"]/100; d_hi=R["frontiers"]["upper_crisis_annual_pct"]/100
r_obs=-np.log(1-d_obs); r_hi=-np.log(1-d_hi)
S=shares(df,BASE); T={}
# inequality indices (shares -> per-capita, budget invariant)
def wgini(x,w):
    i=np.argsort(x); x=x[i]; w=w[i]; xw=x*w; S_=xw.sum(); c=np.cumsum(xw); return 1-2*np.sum(w*(c-xw/2))/(S_*w.sum())
def theil(x,w): w=w/w.sum(); mu=(w*x).sum(); return float((w*(x/mu)*np.log(x/mu)).sum())
def atk(x,w): w=w/w.sum(); mu=(w*x).sum(); return float(1-np.exp((w*np.log(x)).sum())/mu)
def palma(x,w):
    i=np.argsort(x); x=x[i]; w=w[i]/w.sum(); cw=np.cumsum(w); prev=0; b=0; t=0
    for xi,c in zip(x,cw):
        b+=xi*max(0,min(c,0.4)-prev); lo=max(prev,0.9); t+=xi*max(0,c-lo); prev=c
    return t/b
ineq=[]
for r,s in S.items():
    pc=s/pop; ineq.append(dict(Rule=r,Gini=wgini(pc,pop),Theil=theil(pc,pop),Atkinson=atk(pc,pop),Palma=palma(pc,pop),MaxMin=pc.max()/pc.min()))
T["ineq"]=pd.DataFrame(ineq)
# validation vs canonical categories (unit budget, annual framing identical to v8)
B=10.0; tr=E0.sum()-B; gpc=Y*1000/pop
ren=lambda a: np.maximum(a,0.01)/np.maximum(a,0.01).sum()
can={"GF":ren(E0),"EPC":ren(pop),"ECPC":ren(np.maximum(pop/pop.sum()*(B*50+Hh.sum())-Hh,0)),
     "AP":ren(E0-tr*Y/Y.sum())}
inc=np.maximum(gpc-9,0)*pop; rci=0.5*Hh/Hh.sum()+0.5*inc/inc.sum(); can["GDR"]=ren(E0-tr*rci/rci.sum())
T["valid"]=pd.DataFrame([dict(Rule=r,**{c:spearmanr(s,v).correlation for c,v in can.items()}) for r,s in S.items()])
# region-level acceptance at 500 Gt, both frontiers
rows=[]
for r,s in S.items():
    rt=E0/(s*500)
    for lab,rs in [("observed",r_obs),("upper",r_hi)]:
        a=expit(8*(rs-rt)/rs)
        for j,c in enumerate(ORDER): rows.append(dict(Rule=r,frontier=lab,Region=NAMES[c],Bloc=df.Negotiating_bloc[j],decline_pct=(1-np.exp(-rt[j]))*100,accept=a[j]))
T["regions"]=pd.DataFrame(rows)
# decision rules: unanimity of two blocs, 2/3 of regions, double majority (2/3 population and 2/3 emissions)
dec=[]
for B_ in (250,500,650):
    for lab,rs in [("observed",r_obs),("upper",r_hi)]:
        for r,s in S.items():
            rt=E0/(s*B_); a=expit(8*(rs-rt)/rs); yes=a>0.5
            he=(a*pop*H).sum()/(pop*H).sum(); li=(a*pop*L).sum()/(pop*L).sum()
            dec.append(dict(B=B_,frontier=lab,Rule=r,two_bloc=bool(he>0.5 and li>0.5),
                two_thirds_regions=bool(yes.sum()>=6),
                double_majority=bool(pop[yes].sum()>=2/3*pop.sum() and E0[yes].sum()>=2/3*E0.sum()),
                regions_yes=int(yes.sum()),pop_yes_pct=pop[yes].sum()/pop.sum()*100,em_yes_pct=E0[yes].sum()/E0.sum()*100))
T["decision"]=pd.DataFrame(dec)
# bargain: minimum frontier across budgets and physical vs effective allocation at the solution
def bl(rates,rs,idx): a=expit(8*(rs-rates)/rs); return (a*pop*idx).sum()/(pop*idx).sum()
def first_theta(B_,rs,v=1.0):
    eq=S["Equity"]*B_; mk=S["Market"]*B_
    for th in np.linspace(0,1.6,1601):
        A=eq+th*(mk-eq)
        if (A<=0).any(): return None
        G=np.clip((A-eq)*H,0,None).sum(); loss=np.clip((eq-A)*L,0,None)
        Aeff=A+(v*G*loss/loss.sum() if loss.sum()>0 else 0)
        if bl(E0/A,rs,H)>0.5 and bl(E0/Aeff,rs,L)>0.5: return th,A,Aeff,G
    return None
curve=[]
for B_ in np.arange(150,851,25):
    rmin=None; mk=None
    for d in np.linspace(0.02,0.40,761):
        rs=-np.log(1-d)
        if rmin is None and first_theta(B_,rs) is not None: rmin=d
        if mk is None:
            rt=E0/(S["Market"]*B_)
            if bl(rt,rs,H)>0.5 and bl(rt,rs,L)>0.5: mk=d
        if rmin is not None and mk is not None: break
    curve.append(dict(B=B_,bargain_min_frontier_pct=rmin*100,market_min_frontier_pct=mk*100))
T["bargain_curve"]=pd.DataFrame(curve)
sol=first_theta(500,r_hi); th,A,Aeff,G=sol
T["bargain_solution"]=pd.DataFrame(dict(Region=[NAMES[c] for c in ORDER],equity_Gt=S["Equity"]*500,
    physical_Gt=A,effective_Gt=np.where(H,S["Equity"]*500,Aeff),physical_decline_pct=(1-np.exp(-E0/A))*100))
T["bargain_meta"]=pd.DataFrame([dict(theta=th,tonnes_shifted_Gt=G,Gini_physical=wgini(A/pop,pop),
    Gini_effective=wgini(np.where(H,S['Equity']*500,Aeff)/pop,pop))])
# equity-gap fund on new data (hybrid vs equal per capita, annual equivalent of 500 Gt over 50 years)
Aa=S["Hybrid"]*10; bench=10*pop/pop.sum(); gap=Aa-bench
T["fund"]=pd.DataFrame(dict(Region=[NAMES[c] for c in ORDER],gap_Gt_yr=gap,USDbn_at_100=np.abs(gap)*100,
    role=np.where(gap>0,"contributor","recipient")))
for k,v in T.items(): v.to_csv(f"{O}/si_{k}.csv",index=False); print("\n##",k); print(v.round(3).to_string())
