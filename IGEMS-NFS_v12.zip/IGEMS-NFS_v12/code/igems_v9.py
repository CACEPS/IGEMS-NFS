"""IGEMS v9: cumulative-budget, rate-based version of the allocation model.

Changes from v8 (see CHANGELOG in README):
 * baseline rebuilt from public data (build_baseline.py), 37.4 Gt territorial fossil CO2 in 2024;
 * allocation rules unchanged in form; they now yield SHARES of a cumulative budget B (Gt from 2025);
 * each regional budget B_i is converted into a pathway: exponential decline r_i = E0_i / B_i,
   or peak-then-decline where the budget exceeds a stated headroom test;
 * adherence and acceptance are expressed in rate terms against an empirical frontier r*.
"""
import numpy as np, pandas as pd
from scipy.special import expit
from region_map import HIGH, LOW, ORDER

RULES = ["Market", "Equity", "Capacity", "Hybrid"]
BASE = dict(B_total=500.0, hist_resp_coeff=0.40, equity_dev_divisor=10.0, capacity_dev_divisor=30.0,
            forest_multiplier=2.0, hybrid_weights=(0.40, 0.35, 0.25), r_star=None, k=8.0, tau=0.5,
            income_scale=1.0)
# Provisional forest fractions (author to replace with FAO FRA 2020 regional values). Capacity rule -> SI.
FOREST = {"NA":0.36,"EU":0.35,"CN":0.23,"JKP":0.20,"RC":0.47,"LA":0.46,"MENA":0.02,"SSEA":0.30,"SSA":0.27}

def load_baseline(path):
    df = pd.read_csv(path, keep_default_na=False).set_index("Region_code").loc[ORDER].reset_index()
    df["Forest_cover_fraction"] = df.Region_code.map(FOREST)
    return df

def _frac(x): return x / x.sum()

def shares(df, p):
    pop = _frac(df.Population_millions.values); em = _frac(df.Current_emissions_Gt.values)
    hist = _frac(df.Historical_emissions_Gt.values)
    gdppc = df.GDP_trillions_USD.values * 1000 / df.Population_millions.values * p["income_scale"]
    Bn = 1.0  # rules are homogeneous of degree one in the budget; compute shares on a unit budget
    market = em * Bn
    dev = 1.0 / (gdppc / p["equity_dev_divisor"] + 1.0); dev = dev / dev.sum() * Bn * 0.15
    eq = np.maximum(pop * Bn - hist * p["hist_resp_coeff"] * pop * Bn + dev, 0.005 * Bn); eq = eq / eq.sum()
    forest = np.minimum(df.Forest_cover_fraction.values * p["forest_multiplier"], 1.0)
    cdev = 1.0 / (gdppc / p["capacity_dev_divisor"] + 1.0); cap = _frac(forest * cdev)
    wm, we, wc = p["hybrid_weights"]; hyb = wm * market + we * eq + wc * cap
    return dict(Market=market, Equity=eq, Capacity=cap, Hybrid=hyb)

def pathway_rate(E0, Bi, g=0.0, r_post=None):
    """Exponential decline from E0 with cumulative integral Bi: r = E0/Bi (continuous, per year).
    Returns continuous rate r, annual % decline, linear net-zero year."""
    r = E0 / Bi
    return r, (1 - np.exp(-r)) * 100, 2024 + 2 * Bi / E0

def peak_then_decline(E0, Bi, g, r_post):
    """Grow at g until peak year T, then decline at r_post. Solve for T so the integral equals Bi.
    Integral = E0 (e^{gT}-1)/g + E0 e^{gT}/r_post. Returns T (years after 2024) or nan."""
    if E0 / r_post >= Bi: return np.nan
    if g <= 0: return (Bi - E0 / r_post) / E0  # plateau
    # solve e^{gT} (1/g + 1/r_post) = Bi/E0 + 1/g
    x = (Bi / E0 + 1 / g) / (1 / g + 1 / r_post)
    return np.log(x) / g

def run(df, p=None, r_star=None, growth=None):
    P = dict(BASE); P.update(p or {})
    rs = r_star if r_star is not None else P["r_star"]
    S = shares(df, P); E0 = df.Current_emissions_Gt.values; pop = df.Population_millions.values
    rows = []
    for rule, s in S.items():
        Bi = s * P["B_total"]
        r, ann, nz = pathway_rate(E0, Bi)
        for j, code in enumerate(df.Region_code):
            row = dict(Rule=rule, Region_code=code, share=s[j], B_i=Bi[j], E0=E0[j], r=r[j],
                       annual_decline_pct=ann[j], netzero_linear=nz[j], peak_year=np.nan, post_peak_pct=np.nan)
            # surplus test: implied exponential decline slower than a 1%/yr floor -> peak-then-decline
            if growth is not None and rs is not None and r[j] < 0.01:
                T = peak_then_decline(E0[j], Bi[j], growth[code], rs)
                row["peak_year"] = 2024 + T; row["post_peak_pct"] = (1 - np.exp(-rs)) * 100
            if rs is not None:
                row["adherent"] = r[j] <= rs
                row["accept"] = float(expit(P["k"] * (rs - r[j]) / rs))
            row["pop"] = pop[j]
            rows.append(row)
    return pd.DataFrame(rows), P

def bloc_summary(res, tau=0.5):
    out = []
    for rule, sub in res.groupby("Rule", sort=False):
        h = sub[sub.Region_code.isin(HIGH)]; l = sub[sub.Region_code.isin(LOW)]
        he = (h.accept * h["pop"]).sum() / h["pop"].sum(); li = (l.accept * l["pop"]).sum() / l["pop"].sum()
        out.append(dict(Rule=rule, adherence=sub.adherent.mean(), HighEmit=he, LowIncome=li,
                        both=(he > tau) and (li > tau)))
    return pd.DataFrame(out)

def pc_inequality(df, s):
    """Population-weighted Gini of per-capita cumulative entitlements (budget-invariant)."""
    pop = df.Population_millions.values; pc = s / pop
    o = np.argsort(pc); w = pop[o] / pop.sum(); x = pc[o]
    cw = np.cumsum(w); cx = np.cumsum(w * x) / np.sum(w * x)
    B = np.sum(w * (np.concatenate([[0], cx[:-1]]) + cx)) / 1.0
    return 1 - B, pc.max() / pc.min()
