import pandas as pd, numpy as np, json, os
from region_map import REGIONS, AMERICAS_LATAM, AFRICA_SSA, NAMES, ORDER, region_of
O="../outputs"; J={}
f=lambda x,n=2: f"{x:,.{n}f}"
b=pd.read_csv(f"{O}/baseline_v9.csv",keep_default_na=False)
J["S11"]=[[r.Region,r.Region_code,f(r.Current_emissions_Gt),f(r.Population_millions,0),f(r.GDP_trillions_USD,1),f(r.Historical_emissions_Gt,0),str(r.Countries),r.Negotiating_bloc] for r in b.itertuples()]
J["S11tot"]=[f(b.Current_emissions_Gt.sum()),f(b.Population_millions.sum(),0),f(b.GDP_trillions_USD.sum(),1),f(b.Historical_emissions_Gt.sum(),0),str(b.Countries.sum())]
ow=pd.read_csv("../data/owid-co2-data.csv"); y=ow[(ow.year==2024)&ow.iso_code.notna()]
y=y[~y.iso_code.str.startswith("OWID_",na=False)|(y.iso_code=="OWID_KOS")]; y["r"]=y.iso_code.map(region_of)
J["S12"]=[[NAMES[r],", ".join(sorted(y[y.r==r].iso_code.str.replace("OWID_KOS","XKX")))] for r in ORDER]
P=pd.read_csv(f"{O}/pathways_v9.csv"); p5=P[P.B_total==500]
rules=["Market","Equity","Capacity","Hybrid"]
def piv(col,n): t=p5.pivot(index="Region",columns="Rule",values=col); return [[NAMES[c]]+[f(t.loc[NAMES[c],r],n) for r in rules] for c in ORDER]
J["S21"]=piv("B_i_Gt",1); J["S22"]=piv("annual_decline_pct",1); J["S23"]=piv("netzero_linear",0)
s=P[P.surplus]; J["S24"]=[[str(int(r.B_total)),r.Rule,r.Region,f(r.B_i_Gt,1),f(r.peak_year,0)] for r in s.itertuples()]
I=pd.read_csv(f"{O}/si_ineq.csv"); J["S31"]=[[r.Rule,f(r.Gini,3),f(r.Theil,3),f(r.Atkinson,3),f(r.Palma,2),f(r.MaxMin,2)] for r in I.itertuples()]
V=pd.read_csv(f"{O}/si_valid.csv"); J["S32"]=[[r.Rule]+[f(getattr(r,c),2) for c in ["GF","EPC","ECPC","AP","GDR"]] for r in V.itertuples()]
fs=pd.read_csv(f"{O}/frontier_summary.csv",index_col=0).iloc[:,0]
lab={"windows":"All country windows","clean_windows":"Non-crisis windows","clean_declining":"Non-crisis declining windows","countries_declining":"Countries with a non-crisis decline",
 "p50_decl":"Median decline, non-crisis declining (%/yr)","p90_decl":"90th percentile (%/yr)","p95_decl":"95th percentile: observed frontier (%/yr)","p99_decl":"99th percentile (%/yr)",
 "p95_decl_smoothed":"95th percentile, smoothed endpoints (%/yr)","p95_decl_large100":"95th percentile, economies above 100 Mt (%/yr)","max_large100":"Maximum, economies above 100 Mt (%/yr)",
 "p95_incl_crisis":"95th percentile including crises: upper bracket (%/yr)","max_incl_crisis":"Maximum including crises (%/yr)"}
J["S41"]=[[v,(f(float(fs[k])*100,2) if float(fs[k])<1 else f(float(fs[k]),0))] for k,v in lab.items()]
w=pd.read_csv(f"{O}/frontier_windows.csv"); d=w[(w.flag=="none")&(w.decline>0)&(w.E_start_Mt>=100)].sort_values("decline",ascending=False).drop_duplicates("iso").head(10)
J["S42"]=[[r.country,f"{r.start} to {r.end}",f(r.E_start_Mt,0),f(r.decline*100,2)] for r in d.itertuples()]
G=pd.read_csv(f"{O}/si_regions.csv",keep_default_na=False)
J["S43"]=[[NAMES[c]]+[f"{f(G[(G.Rule==r)&(G.Region==NAMES[c])&(G.frontier=='observed')].accept.iloc[0],2)} / {f(G[(G.Rule==r)&(G.Region==NAMES[c])&(G.frontier=='upper')].accept.iloc[0],2)}" for r in rules] for c in ORDER]
D=pd.read_csv(f"{O}/si_decision.csv"); yn=lambda x:"Yes" if x else "No"
J["S44"]=[[str(r.B),"Observed" if r.frontier=="observed" else "Upper",r.Rule,yn(r.two_bloc),yn(r.two_thirds_regions),yn(r.double_majority),str(r.regions_yes)] for r in D.itertuples()]
BS=pd.read_csv(f"{O}/budget_sensitivity_v9.csv"); J["S51"]=[[str(r.B_total),r.Rule,f(r.adherence,2),f(r.HighEmit,3),f(r.LowIncome,3),yn(r.both)] for r in BS.itertuples()]
R=json.load(open(f"{O}/results_v9.json")); sw=R["switching"]
J["S52"]=[[k,f(v["global_required_annual_pct"],1),f(v["rstar_switch_annual_pct"],1),f(v["multiple_of_observed"],2),v["rule_that_clears_first"],f(v["tau_switch"],3),"none" if v["k_values_clearing"] is None else str(v["k_values_clearing"])] for k,v in sw.items()]
mc=R["monte_carlo"]; J["S53"]=[]
for B in ("250","500"):
    m=mc[B]; J["S53"].append([B,f(m["any_rule_clears_share"]*100,1)+"%"]+[f(m["by_rule"][r]*100,1)+"%" for r in rules]+["n/a" if m["min_rstar_in_clearing_draws"] is None else f(m["min_rstar_in_clearing_draws"]*100,2),f(m["market_last_on_adherence"]*100,1)+"%",f(m["hybrid_adh_mean"],2)])
bs=pd.read_csv(f"{O}/si_bargain_solution.csv"); J["S61"]=[[r.Region,f(r.equity_Gt,1),f(r.physical_Gt,1),f(r.effective_Gt,1),f(r.physical_decline_pct,1)] for r in bs.itertuples()]
bc=pd.read_csv(f"{O}/si_bargain_curve.csv"); bc=bc[bc.B.isin([150,200,250,300,400,500,600,650,700,800])]
J["S62"]=[[str(r.B),f(r.market_min_frontier_pct,2),f(r.bargain_min_frontier_pct,2)] for r in bc.itertuples()]
bg=R["bargain"]; J["S63"]=[]
for k,lab_ in [("B500_crisis_upper","500 Gt, upper frontier"),("B650_crisis_upper","650 Gt, upper frontier")]:
    e=bg[k]; J["S63"].append([lab_,f(e["theta_min"],2),f(e["transfer_cum_USDbn_at100"]/1000,1),f(e["transfer_avg_2025_2050_USDbn_per_yr"],0),f(e["transfer_peak_USDbn_per_yr"],0)])
fu=pd.read_csv(f"{O}/si_fund.csv"); J["S64"]=[[r.Region,r.role,f(abs(r.gap_Gt_yr),2),f(abs(r.gap_Gt_yr)*75,0),f(abs(r.gap_Gt_yr)*150,0)] for r in fu.itertuples()]
K=pd.read_csv(f"{O}/kyoto_backtest.csv",keep_default_na=False)
J["S71"]=[[r.iso,f(r.target_pct,1),f(r.actual_pct,1),f(r.perf,1),f(r.fair_dist_signed,2),"Yes" if r.EIT in (True,"True") else "No",r.nonparty or "Party"] for r in K.itertuples()]
KT=pd.read_csv(f"{O}/kyoto_backtest_tests.csv")
lab2={"all":"All parties","parties_only":"Ratifying parties","non_EIT":"Excluding EITs"}
J["S72"]=[[lab2[r.sample],"Absolute" if r.measure=="fair_dist_abs" else "Signed","Spearman" if r.test=="spearman" else "Partial, EIT controlled",str(r.n),f(r.rho,2),f(r.p,3)] for r in KT.itertuples()]
json.dump(J,open("/home/claude/build/si.json","w"),ensure_ascii=False)
print({k:len(v) for k,v in J.items()})
