import pandas as pd, numpy as np, os, json, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from igems_v9 import load_baseline, shares, BASE
from region_map import ORDER, NAMES, HIGH
O=os.path.join(os.path.dirname(__file__),"..","outputs"); F=os.path.join(os.path.dirname(__file__),"..","figures")
df=load_baseline(f"{O}/baseline_v9.csv"); E0=df.Current_emissions_Gt.values
R=json.load(open(f"{O}/results_v9.json")); d_obs=R["frontiers"]["observed_annual_pct"]; d_hi=R["frontiers"]["upper_crisis_annual_pct"]
S=shares(df,BASE); plt.rcParams.update({"font.family":"serif","font.size":8.5})
short={"NA":"N. America","EU":"Europe","CN":"China","JKP":"Japan, Korea\n& Pacific","RC":"Russia &\nC. Asia","LA":"Latin\nAmerica","MENA":"MENA","SSEA":"South &\nSE Asia","SSA":"Sub-Saharan\nAfrica"}
# Figure 2 palettes. Greyscale reproduces the print version; colour uses the colourblind-safe
# Okabe-Ito palette. Line styles differ in both, so the colour figure also reads in greyscale.
PALETTES={
 "fig2_results":dict(market="0.75",equity="0.2",hybrid="0.5",obs="k",hi="k",uni="k",barg="k",phys="0.55",eff="0.15",lw=1,lw2=1.5),
 "fig2_results_colour":dict(market="#E69F00",equity="#0072B2",hybrid="#009E73",obs="#D55E00",hi="#CC79A7",
                            uni="#E69F00",barg="#56B4E9",phys="#009E73",eff="#0072B2",lw=1.2,lw2=1.6)}
for stem,C in PALETTES.items():
    fig=plt.figure(figsize=(7.2,8.6)); gs=fig.add_gridspec(2,2,height_ratios=[1,1],hspace=0.38,wspace=0.62)
    ax=fig.add_subplot(gs[0,:]); x=np.arange(9); wdt=0.26
    for k,(rule,col) in enumerate([("Market",C["market"]),("Equity",C["equity"]),("Hybrid",C["hybrid"])]):
        v=(1-np.exp(-E0/(S[rule]*500)))*100; ax.bar(x+(k-1)*wdt,np.minimum(v,30),wdt,color=col,label=rule,edgecolor="k",lw=0.3)
    ax.axhline(d_obs,color=C["obs"],lw=C["lw"],label="Observed frontier %.1f%%"%d_obs); ax.axhline(d_hi,color=C["hi"],ls="--",lw=C["lw"],label="Crisis-inclusive %.1f%%"%d_hi)
    ax.axvline(4.5,color="0.6",lw=0.6,ls=":"); ax.text(2,28.3,"High-emitting bloc",ha="center",fontsize=7.5,style="italic"); ax.text(6.5,28.3,"Lower-income bloc",ha="center",fontsize=7.5,style="italic")
    ax.set_xticks(x); ax.set_xticklabels([short[c] for c in ORDER],fontsize=6.8); ax.set_ylim(0,30); ax.set_ylabel("Required annual decline (%)")
    ax.set_title("a  Required decline rates under a 500 Gt budget from 2025",loc="left"); ax.legend(frameon=False,ncol=2,loc="upper right",bbox_to_anchor=(1.0,0.92),fontsize=7.2)
    ax2=fig.add_subplot(gs[1,0]); bc=pd.read_csv(f"{O}/si_bargain_curve.csv")
    ax2.plot(bc.B,bc.market_min_frontier_pct,"-",color=C["uni"],lw=C["lw2"],label="Uniform cuts (market)")
    ax2.plot(bc.B,bc.bargain_min_frontier_pct,"-.",color=C["barg"],lw=C["lw2"],label="Physical-financial bargain")
    ax2.axhline(d_obs,color=C["obs"],lw=C["lw"]); ax2.axhline(d_hi,color=C["hi"],ls="--",lw=C["lw"])
    for b in (130,250,500,650): ax2.axvline(b,color="0.85",lw=0.6)
    ax2.set_ylim(0,25); ax2.set_xlim(150,850); ax2.set_xlabel("Cumulative CO$_2$ budget from 2025 (Gt)"); ax2.set_ylabel("Frontier needed to clear both blocs (%/yr)")
    ax2.set_title("b  Switching frontier",loc="left"); ax2.legend(frameon=False,fontsize=7)
    ax3=fig.add_subplot(gs[1,1]); bs=pd.read_csv(f"{O}/si_bargain_solution.csv"); y=np.arange(9)
    ax3.barh(y+0.2,bs.physical_Gt,0.4,color=C["phys"],label="Physical allocation",edgecolor="k",lw=0.3)
    ax3.barh(y-0.2,bs.effective_Gt,0.4,color=C["eff"],label="Effective entitlement",edgecolor="k",lw=0.3)
    ax3.set_yticks(y); ax3.set_yticklabels([short[c].replace("\n"," ") for c in ORDER],fontsize=7); ax3.invert_yaxis()
    ax3.set_xlabel("Cumulative Gt CO$_2$, 2025 onward"); ax3.set_title("c  Bargain at 500 Gt, upper frontier",loc="left"); ax3.legend(frameon=False,fontsize=7,loc="center right")
    fig.savefig(f"{F}/{stem}.png",dpi=300,bbox_inches="tight"); fig.savefig(f"{F}/{stem}.pdf",bbox_inches="tight"); plt.close(fig)
# Figure 1: governance sequence
fig,ax=plt.subplots(figsize=(7.2,3.1)); ax.axis("off"); ax.set_xlim(0,100); ax.set_ylim(0,42)
boxes=[(1,"1  Boundary","Cumulative CO$_2$ budget\nfixed by assessment,\nchecked against the\nfeasibility frontier","0.92"),
       (26,"2  Allocation","Physical pathways and\nequity entitlements are\nnegotiated as two\nseparate vectors","0.82"),
       (51,"3  Transfer","Payments close the gap\nbetween physical tonnes\nand entitlements, so\nboth blocs can accept","0.72"),
       (76,"4  Markets","Article 6 trading within\nthe ceiling, on corridor\ncentres and a public\nledger","0.92")]
for x0,t,b,c in boxes:
    ax.add_patch(FancyBboxPatch((x0,8),22,28,boxstyle="round,pad=0.4",fc=c,ec="k",lw=0.8))
    ax.text(x0+11,32,t,ha="center",va="center",fontsize=9,weight="bold"); ax.text(x0+11,19.5,b,ha="center",va="center",fontsize=6.9)
for x0 in (23.4,48.4,73.4): ax.annotate("",xy=(x0+2.4,22),xytext=(x0,22),arrowprops=dict(arrowstyle="->",lw=1))
labels=[(12,"Reform 1: Planetary\nBoundary Protocol"),(37,"Reform 2: Differentiated\nCarbon Corridors"),(62,"Reform 3: Climate\nSolidarity Fund"),(87,"Existing Article 6\nrules, refined")]
for x0,l in labels: ax.text(x0,3,l,ha="center",va="center",fontsize=7,style="italic")
ax.text(50,40.5,"Entry point: the 2028 Global Stocktake, mandated to proceed in the light of equity and the best available science",ha="center",fontsize=7.5)
fig.savefig(f"{F}/fig1_framework.png",dpi=300,bbox_inches="tight"); fig.savefig(f"{F}/fig1_framework.pdf",bbox_inches="tight")
