"""Workstream 3.2 (PENDING DATA): modelled decline-rate frontier from the AR6 Scenario Database.
Download 'AR6_Scenarios_Database_R10_regions' and the meta file from the IIASA AR6 Scenario Explorer
(Byers et al., 2022; login required, licence restricts redistribution) into data/ar6/.
Then run this script. It extracts Emissions|CO2|Energy and Industrial Processes for C1 and C3
pathways, computes 10-year compound declines 2030-2060 by R10 region, and writes the p50 and p95."""
import pandas as pd, numpy as np, os, glob, sys
D=os.path.join(os.path.dirname(__file__),"..","data","ar6"); O=os.path.join(os.path.dirname(__file__),"..","outputs")
files=glob.glob(f"{D}/*R10*.csv"); meta=glob.glob(f"{D}/*meta*.xlsx")
if not files or not meta: sys.exit("AR6 R10 file and meta file not found in data/ar6/. See docstring.")
x=pd.read_csv(files[0]); m=pd.read_excel(meta[0],sheet_name="meta")[["Model","Scenario","Category"]]
x=x[x.Variable=="Emissions|CO2|Energy and Industrial Processes"].merge(m,on=["Model","Scenario"])
x=x[x.Category.isin(["C1","C3"])]
rows=[]
for _,r in x.iterrows():
    for y0 in range(2030,2051,5):
        a,b=r.get(str(y0)),r.get(str(y0+10))
        if pd.notna(a) and pd.notna(b) and a>0 and b>0:
            rows.append(dict(Category=r.Category,Region=r.Region,start=y0,decline=1-(b/a)**0.1))
w=pd.DataFrame(rows)
s=w.groupby(["Category","Region"]).decline.describe(percentiles=[.5,.95])[["count","50%","95%"]]
s.to_csv(f"{O}/frontier_modelled_AR6.csv"); print(s)
