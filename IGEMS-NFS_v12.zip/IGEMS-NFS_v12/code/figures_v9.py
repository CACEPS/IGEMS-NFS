import pandas as pd, numpy as np, os, json, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from igems_v9 import load_baseline, shares, BASE
from region_map import HIGH
O=os.path.join(os.path.dirname(__file__),"..","outputs"); F=os.path.join(os.path.dirname(__file__),"..","figures")
w=pd.read_csv(f"{O}/frontier_windows.csv"); R=json.load(open(f"{O}/results_v9.json"))
d_obs=R["frontiers"]["observed_annual_pct"]; d_hi=R["frontiers"]["upper_crisis_annual_pct"]
df=load_baseline(f"{O}/baseline_v9.csv"); E0=df.Current_emissions_Gt.values; H=df.Region_code.isin(HIGH).values
plt.rcParams.update({"font.family":"serif","font.size":9})
fig,ax=plt.subplots(1,2,figsize=(10,3.8))
clean=w[(w.flag=="none")&(w.decline>0)].decline*100; crisis=w[(w.flag!="none")&(w.decline>0)].decline*100
bins=np.arange(0,21,0.5)
ax[0].hist(clean,bins=bins,color="0.35",label="Non-crisis declining windows")
ax[0].hist(crisis,bins=bins,color="0.8",label="Crisis windows",alpha=0.9)
for x,l,ls in [(d_obs,"Observed frontier (p95)","-"),(d_hi,"Crisis-inclusive p95","--")]:
    ax[0].axvline(x,color="k",ls=ls,lw=1); ax[0].text(x+0.2,ax[0].get_ylim()[1]*0.85,l,rotation=90,va="top",fontsize=7)
ax[0].set_xlabel("10-year compound annual CO$_2$ decline (%)"); ax[0].set_ylabel("Country windows")
ax[0].set_title("a  Observed decline rates, 1970 to 2024",loc="left"); ax[0].legend(frameon=False,fontsize=7)
B=np.linspace(100,800,200)
glob=(1-np.exp(-E0.sum()/B))*100
ax[1].plot(B,glob,"k-",label="Rate every region needs under uniform cuts")
ax[1].axhline(d_obs,color="k",lw=1); ax[1].axhline(d_hi,color="k",ls="--",lw=1)
ax[1].text(110,d_obs+0.4,"Observed frontier %.1f%%"%d_obs,fontsize=7); ax[1].text(110,d_hi+0.4,"Crisis-inclusive %.1f%%"%d_hi,fontsize=7)
ax[1].fill_between(B,glob,30,color="0.9")
ax[1].text(560,24,"Some rule clears both blocs\nonly if r* lies in this area",fontsize=7)
hepct=(E0*H).sum()
ax[1].axvline(hepct/(-np.log(1-d_obs/100)),color="0.5",ls=":",lw=1)
ax[1].text(hepct/(-np.log(1-d_obs/100))+8,20,"High emitters' own need\nat observed frontier",fontsize=7)
for b in (130,250,500,650): ax[1].axvline(b,color="0.85",lw=0.6)
ax[1].set_ylim(0,30); ax[1].set_xlabel("Cumulative CO$_2$ budget from 2025 (Gt)"); ax[1].set_ylabel("Annual decline (%)")
ax[1].set_title("b  Switching frontier for gridlock",loc="left"); ax[1].legend(frameon=False,fontsize=7,loc="upper right")
fig.tight_layout(); fig.savefig(f"{F}/figS_frontier_switching.png",dpi=200); fig.savefig(f"{F}/figS_frontier_switching.pdf")
# fund reconciliation on new data: equal per-capita gap under hybrid, annualised at B/50
S=shares(df,BASE); pop=df.Population_millions.values
for Bt in (500,):
    A=S["Hybrid"]*Bt/50; bench=Bt/50*pop/pop.sum(); gap=np.clip(bench-A,0,None).sum()
    print("equity-gap fund, hybrid, Gt/yr %.2f -> USD %.0f to %.0f bn/yr at 75-150"%(gap,gap*75,gap*150))
