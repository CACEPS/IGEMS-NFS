import pandas as pd, numpy as np, os
from igems_v9 import load_baseline, run, bloc_summary, shares, pc_inequality, BASE
from region_map import NAMES
O=os.path.join(os.path.dirname(__file__),"..","outputs")
df=load_baseline(f"{O}/baseline_v9.csv")
fs=pd.read_csv(f"{O}/frontier_summary.csv",index_col=0).iloc[:,0]
d_obs=float(fs["p95_decl"]); r_obs=-np.log(1-d_obs)
print("observed frontier annual %.2f%%, continuous %.4f"%(d_obs*100,r_obs))
S=shares(df,BASE)
for rule,s in S.items():
    g,mm=pc_inequality(df,s); print(f"{rule:9s} Gini {g:.3f}  max:min {mm:.2f}")
allb=[]
for B in [130,250,420,500,580,650]:
    res,P=run(df,dict(B_total=B),r_star=r_obs)
    bs=bloc_summary(res); bs.insert(0,"B_total",B); allb.append(bs)
    if B in (500,):
        t=res.pivot(index="Region_code",columns="Rule",values="annual_decline_pct")[["Market","Equity","Capacity","Hybrid"]]
        nz=res.pivot(index="Region_code",columns="Rule",values="netzero_linear")[["Market","Equity","Capacity","Hybrid"]]
        print("B=500 required annual decline %:\n",t.loc[df.Region_code].round(2)); print("linear net-zero year:\n",nz.loc[df.Region_code].round(0))
bb=pd.concat(allb); bb.to_csv(f"{O}/budget_sensitivity_v9.csv",index=False); print(bb.round(3).to_string())
