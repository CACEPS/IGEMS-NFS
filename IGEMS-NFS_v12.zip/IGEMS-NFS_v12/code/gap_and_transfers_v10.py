"""v10 additions (Climate Policy resubmission).

1. Physical gap: cumulative emissions needed if every region declines at the observed frontier,
   compared with each budget. The shortfall is what removals or faster-than-recorded decline
   must supply.
2. Bargain transfer totals: cumulative transfer, 2025-2050 window, and post-2050 tail at USD 100/t.
3. Records the Monte Carlo frontier sampling rule used in analysis_v9.py (uniform in annual decline
   between the observed p95 and the crisis-inclusive p95).
Reads outputs written by analysis_v9.py; writes outputs/results_v10_additions.json.
"""
import json, os
import numpy as np
import pandas as pd

O = os.path.join(os.path.dirname(__file__), "..", "outputs")
res = json.load(open(f"{O}/results_v9.json"))
base = pd.read_csv(f"{O}/baseline_v9.csv")
fs = pd.read_csv(f"{O}/frontier_summary.csv", index_col=0).iloc[:, 0]

E_total = float(base.Current_emissions_Gt.sum())
d_obs, d_hi = float(fs["p95_decl"]), float(fs["p95_incl_crisis"])
r_obs, r_hi = -np.log(1 - d_obs), -np.log(1 - d_hi)
YEARS = 50

out = {"E_total_Gt": E_total,
       "frontier_observed_annual_pct": d_obs * 100,
       "frontier_upper_annual_pct": d_hi * 100,
       "monte_carlo_frontier_sampling": "uniform in annual decline rate between observed p95 and crisis-inclusive p95",
       "physical_gap": {}}

need_obs = E_total / r_obs   # cumulative emissions under uniform decline at the observed frontier
for B in [130, 250, 500, 650]:
    gap = need_obs - B
    out["physical_gap"][str(B)] = dict(
        cumulative_need_at_observed_frontier_Gt=need_obs,
        shortfall_Gt=gap,
        shortfall_Gt_per_yr_over_50yr=gap / YEARS,
        required_uniform_annual_pct=(1 - np.exp(-E_total / B)) * 100)

bg = res["bargain"]
tr = {}
for key in ["B500_crisis_upper", "B650_crisis_upper"]:
    e = bg[key]
    if not e.get("feasible"):
        continue
    cum = e["transfer_cum_USDbn_at100"]
    win = e["transfer_avg_2025_2050_USDbn_per_yr"] * 26
    tr[key] = dict(theta=e["theta_min"],
                   tonnes_shifted_Gt=cum / 100.0,
                   cumulative_USDbn=cum,
                   window_2025_2050_USDbn=win,
                   post_2050_tail_USDbn=cum - win,
                   avg_2025_2050_USDbn_per_yr=e["transfer_avg_2025_2050_USDbn_per_yr"],
                   peak_USDbn_per_yr=e["transfer_peak_USDbn_per_yr"])
out["bargain_transfer_totals_at_USD100"] = tr
out["bargain_min_frontier_annual_pct"] = {B: bg[f"B{B}_min_frontier_for_bargain_annual_pct"] for B in [250, 500, 650]}

json.dump(out, open(f"{O}/results_v10_additions.json", "w"), indent=1)
print(json.dumps(out, indent=1))
