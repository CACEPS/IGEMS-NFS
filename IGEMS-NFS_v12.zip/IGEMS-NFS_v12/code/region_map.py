"""Country to IGEMS region mapping (v9). Author decisions flagged in REGION_NOTES."""
NA  = ["USA","CAN"]
EU  = ["AUT","BEL","BGR","HRV","CYP","CZE","DNK","EST","FIN","FRA","DEU","GRC","HUN","IRL","ITA",
       "LVA","LTU","LUX","MLT","NLD","POL","PRT","ROU","SVK","SVN","ESP","SWE",
       "GBR","NOR","CHE","ISL","LIE","AND","MCO","SMR","FRO","GRL",
       "ALB","BIH","MNE","MKD","SRB","OWID_KOS","TUR"]
CN  = ["CHN","HKG","MAC","MNG"]
JKP = ["JPN","KOR","TWN","AUS","NZL"]
RC  = ["RUS","UKR","BLR","MDA","ARM","AZE","GEO","KAZ","KGZ","TJK","TKM","UZB"]
MENA= ["DZA","BHR","DJI","EGY","IRN","IRQ","ISR","JOR","KWT","LBN","LBY","MAR","OMN","PSE",
       "QAT","SAU","SYR","TUN","ARE","YEM"]
SSEA= ["AFG","BGD","BTN","IND","MDV","NPL","PAK","LKA",
       "BRN","KHM","IDN","LAO","MYS","MMR","PHL","SGP","THA","TLS","VNM","PRK",
       "PNG","FJI","SLB","VUT","WSM","TON","KIR","FSM","MHL","PLW","NRU","TUV","NCL","PYF","COK","NIU"]
LA_EXTRA_OK = True  # all remaining Americas go to Latin America
REGIONS = {"NA":NA,"EU":EU,"CN":CN,"JKP":JKP,"RC":RC,"MENA":MENA,"SSEA":SSEA}
NAMES = {"NA":"North America","EU":"Europe","CN":"China","JKP":"Japan, Korea & Pacific",
         "RC":"Russia & Central Asia","LA":"Latin America","MENA":"Middle East & N. Africa",
         "SSEA":"South & Southeast Asia","SSA":"Sub-Saharan Africa"}
ORDER = ["NA","EU","CN","JKP","RC","LA","MENA","SSEA","SSA"]
HIGH = ["NA","EU","CN","JKP","RC"]; LOW = ["LA","MENA","SSEA","SSA"]
BLOC = {"NA":"Umbrella Group","EU":"EU and European parties","CN":"BASIC/LMDC (China)",
        "JKP":"Umbrella Group/EIG","RC":"Umbrella Group/EIT","LA":"GRULAC (AILAC/ALBA)",
        "MENA":"Arab Group","SSEA":"LMDC/G77 and LDC (Asia)","SSA":"African Group/LDC"}
AMERICAS_LATAM = ["MEX","GTM","BLZ","SLV","HND","NIC","CRI","PAN","CUB","JAM","HTI","DOM","BHS","BRB",
    "TTO","ATG","DMA","GRD","KNA","LCA","VCT","COL","VEN","GUY","SUR","ECU","PER","BOL","BRA","PRY",
    "URY","ARG","CHL","ABW","CUW","SXM","BMU","CYM","TCA","VGB","AIA","MSR","PRI","FLK","BES","GLP","MTQ","GUF"]
AFRICA_SSA = ["AGO","BEN","BWA","BFA","BDI","CPV","CMR","CAF","TCD","COM","COD","COG","CIV","GNQ","ERI",
    "SWZ","ETH","GAB","GMB","GHA","GIN","GNB","KEN","LSO","LBR","MDG","MWI","MLI","MRT","MUS","MOZ",
    "NAM","NER","NGA","RWA","STP","SEN","SYC","SLE","SOM","ZAF","SSD","SDN","TZA","TGO","UGA","ZMB",
    "ZWE","SHN","MYT","REU","ESH"]
REGION_NOTES = [
 "Turkey placed in Europe, following the AR6 R10 convention.",
 "Taiwan, Australia and New Zealand join Japan and Korea as a Pacific high-income region.",
 "Southeast Asia and the Pacific islands join South Asia; region renamed South & Southeast Asia.",
 "Mexico placed in Latin America. Sudan in Sub-Saharan Africa (World Bank convention).",
 "International aviation and shipping bunkers are excluded (territorial accounting).",
]
def region_of(iso):
    for r,l in REGIONS.items():
        if iso in l: return r
    if iso in AMERICAS_LATAM: return "LA"
    if iso in AFRICA_SSA: return "SSA"
    return None
