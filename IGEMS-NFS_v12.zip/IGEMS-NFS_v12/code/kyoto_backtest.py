"""Workstream 6.1: Kyoto first commitment period back-test (n ~ 37 Annex B parties).
Performance = target (% of base year) minus actual 2008-2012 mean domestic emissions (% of base year),
excluding flexibility credits and LULUCF (OWID total_ghg_excluding_lucf: CO2+CH4+N2O, no F-gases).
Fairness distance = gap between the Kyoto assigned amount and the IGEMS equity-rule allocation
computed over Annex B parties with the Annex B aggregate target as the budget.
Targets: Kyoto Annex B; EU-15 members use the 1998 EU burden-sharing agreement (Council Decision 2002/358/EC).
AUTHOR: verify every target and base year against Shishlov, Morel and Bellassen (2016) before use."""
import pandas as pd, numpy as np, os
from scipy.stats import spearmanr
D=os.path.join(os.path.dirname(__file__),"..","data"); O=os.path.join(os.path.dirname(__file__),"..","outputs")
T={"AUT":-13,"BEL":-7.5,"DNK":-21,"FIN":0,"FRA":0,"DEU":-21,"GRC":25,"IRL":13,"ITA":-6.5,"LUX":-28,
   "NLD":-6,"PRT":27,"ESP":15,"SWE":4,"GBR":-12.5,
   "BGR":-8,"CZE":-8,"EST":-8,"LVA":-8,"LTU":-8,"ROU":-8,"SVK":-8,"SVN":-8,"CHE":-8,"LIE":-8,"MCO":-8,
   "HRV":-5,"HUN":-6,"POL":-6,"JPN":-6,"CAN":-6,"USA":-7,"NZL":0,"RUS":0,"UKR":0,"NOR":1,"AUS":8,"ISL":10}
BASEYR={"BGR":[1988],"HUN":[1985,1986,1987],"POL":[1988],"ROU":[1989],"SVN":[1986]}
EIT=set("BGR CZE EST LVA LTU ROU SVK SVN HRV HUN POL RUS UKR".split())
NONPARTY={"USA":"never ratified","CAN":"withdrew Dec 2011"}
d=pd.read_csv(f"{D}/owid-co2-data.csv"); g=pd.read_csv(f"{D}/wb_gdp_current_usd.csv")
rows=[]
for iso,t in T.items():
    s=d[d.iso_code==iso].set_index("year")
    if s.empty or pd.isna(s.loc[1990,"total_ghg_excluding_lucf"]): continue
    by=BASEYR.get(iso,[1990]); base=s.loc[by,"total_ghg_excluding_lucf"].mean()
    act=s.loc[2008:2012,"total_ghg_excluding_lucf"].mean()
    gg=g[(g["Country Code"]==iso)&(g.Year<=1995)].sort_values("Year")
    gdp=gg.Value.iloc[0] if len(gg) else np.nan; gyr=gg.Year.iloc[0] if len(gg) else np.nan
    pop=s.loc[1990,"population"]
    rows.append(dict(iso=iso,target_pct=100+t,base=base,actual_0812=act,actual_pct=100*act/base,
        perf=100+t-100*act/base, AA=base*(100+t)/100, pop=pop, cum_co2_1990=s.loc[1990,"cumulative_co2"],
        gdppc_k=gdp/pop/1000, gdp_year=gyr, EIT=iso in EIT, nonparty=NONPARTY.get(iso,"")))
K=pd.DataFrame(rows)
# IGEMS equity rule over Annex B, budget = aggregate assigned amount
B=K.AA.sum(); popf=K["pop"]/K["pop"].sum(); histf=K.cum_co2_1990/K.cum_co2_1990.sum()
dev=1/(K.gdppc_k/10+1); dev=dev/dev.sum()*B*0.15
eq=np.maximum(popf*B-histf*0.40*popf*B+dev,0.005*B); K["equity_alloc"]=eq/eq.sum()*B
K["fair_dist_signed"]=(K.AA-K.equity_alloc)/K.equity_alloc   # >0: target more generous than equity
K["fair_dist_abs"]=K.fair_dist_signed.abs()
K.to_csv(f"{O}/kyoto_backtest.csv",index=False)
def partial_spearman(x,y,z):
    rx=pd.Series(x).rank().values; ry=pd.Series(y).rank().values; Z=np.c_[np.ones(len(z)),z.astype(float)]
    ex=rx-Z@np.linalg.lstsq(Z,rx,rcond=None)[0]; ey=ry-Z@np.linalg.lstsq(Z,ry,rcond=None)[0]
    from scipy.stats import pearsonr; return pearsonr(ex,ey)
res={}
for lab,sub in [("all",K),("parties_only",K[K.nonparty==""]),("non_EIT",K[~K.EIT])]:
    for v in ["fair_dist_abs","fair_dist_signed"]:
        rho,p=spearmanr(sub[v],sub.perf); res[(lab,v,"spearman")]=(len(sub),rho,p)
        if lab!="non_EIT":
            r,pp=partial_spearman(sub[v].values,sub.perf.values,sub.EIT.values); res[(lab,v,"partial|EIT")]=(len(sub),r,pp)
R=pd.DataFrame([dict(sample=a,measure=b,test=c,n=v[0],rho=v[1],p=v[2]) for (a,b,c),v in res.items()])
R.to_csv(f"{O}/kyoto_backtest_tests.csv",index=False)
print(K[["iso","target_pct","actual_pct","perf","fair_dist_signed","EIT"]].round(2).to_string())
print(R.round(3).to_string())
print("mean perf EIT %.1f, non-EIT %.1f"%(K[K.EIT].perf.mean(),K[~K.EIT].perf.mean()))
