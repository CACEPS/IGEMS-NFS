#!/usr/bin/env bash
# Reproduce every output and figure of the IGEMS-NFS v11 release.
set -euo pipefail
cd "$(dirname "$0")/code"
for s in build_baseline.py frontier_observed.py run_base.py analysis_v9.py gap_and_transfers_v10.py \
         kyoto_backtest.py si_tables_v9.py si_json.py figures_v9.py main_figures_v9.py; do
  echo "== $s"
  python3 "$s" > /dev/null
done
echo "Done. Results in outputs/ and figures/."
