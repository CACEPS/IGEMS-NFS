# Changelog

## v11
* No model equation, parameter, data file or numerical output changed. A fresh end-to-end run reproduces
  every v10 output exactly (all CSV and JSON files compared).
* `main_figures_v9.py` now writes a colour version of Figure 2 (`figures/fig2_results_colour.png/.pdf`)
  using the colourblind-safe Okabe-Ito palette. The greyscale Figure 2 is unchanged.
* Added `run_all.sh`, `requirements.txt`, `CHANGELOG.md`, `CITATION.cff` and `.gitignore`.
* README updated to the manuscript title as submitted, with a run-order table and a map from headline
  numbers to output files.

## v10
* Added `gap_and_transfers_v10.py`: physical gap at the observed frontier, bargain transfer totals
  including the post-2050 tail, and an explicit statement of the Monte Carlo frontier sampling rule.
* Kyoto back-test interpretation revised; code unchanged.

## v9
* Baseline rebuilt from public 2024 data (37.4 Gt, 8.15 billion people) with full country coverage.
* Cumulative budgets from 2025; allocations converted into pathways and required decline rates.
* Empirical decline frontier from national records, 1970 to 2024, with crisis episodes separated.
* Rate-based adherence and acceptance; 1,000-draw Monte Carlo with behavioural parameters;
  switching values; physical and financial bargain; 37-party Kyoto back-test.
* Removed: the 10 Gt annual ceiling, the stylised 32 Gt baseline, cut-depth thresholds, the stylised cost
  and delivery calculation, and the unsourced Kyoto compliance figures.
