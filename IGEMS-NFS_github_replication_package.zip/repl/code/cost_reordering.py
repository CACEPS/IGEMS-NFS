"""Stylized cost reordering under delivery weighting.

This is a transparent stand-in for a full IAM coupling, not a substitute.
It tests one hypothesis with a single common cost function: a rule that
looks cheap on static abatement cost can become expensive once cost is
weighted by the probability that the required cut is actually delivered.

Cost model (deliberately simple and common across rules so the allocation
does the work, not region-specific guesses):
  Marginal abatement cost rises linearly with the depth of cut fraction.
  MAC_i(cut) = kappa * cut_i, with kappa a common scale (set to 100 USD/t
  at a full cut so numbers read in USD/t).
  Static abatement cost of region i = integral = 0.5 * kappa * cut_i * R_i,
  where R_i is the physical reduction in Gt.
  Expected delivered reduction = acceptance_i * R_i.
  Effective cost per delivered tonne = total static cost / total expected
  delivered reduction.

We report both the naive static cost per tonne (delivery ignored) and the
delivery-weighted cost per tonne, for each rule.
"""

import numpy as np
import pandas as pd
from igems_model import run, MECHANISMS

KAPPA = 100.0  # USD per tonne at a full (100 percent) cut; scale only

res, _ = run()
E = res["Current_emissions_Gt"].values
rows = []
for m in MECHANISMS:
    A = res[f"{m}_allocation_Gt"].values
    R = np.maximum(E - A, 0.0)                     # physical reduction, Gt
    cut = np.clip(R / E, 0, 1)
    acc = res[f"{m}_acceptance_propensity"].values
    static_cost = 0.5 * KAPPA * cut * R            # USD-bn-equivalent units (Gt x USD/t)
    total_static = static_cost.sum()
    total_R = R.sum()
    delivered = (acc * R).sum()
    rows.append(dict(
        Rule=m,
        Total_reduction_Gt=round(total_R, 2),
        Expected_delivered_Gt=round(delivered, 2),
        Delivery_ratio=round(delivered / total_R, 3),
        Static_cost_per_t=round(total_static / total_R, 1),
        Effective_cost_per_t=round(total_static / delivered, 1),
    ))
cost = pd.DataFrame(rows)
cost.to_csv("../outputs/cost_reordering.csv", index=False)
print(cost.to_string(index=False))

# ranking check
naive_rank = cost.sort_values("Static_cost_per_t")["Rule"].tolist()
eff_rank = cost.sort_values("Effective_cost_per_t")["Rule"].tolist()
print("\nCheapest-first on STATIC cost:   ", naive_rank)
print("Cheapest-first on EFFECTIVE cost:", eff_rank)
mkt = cost.set_index("Rule").loc["Market"]
print(f"\nMarket static cost/t = {mkt.Static_cost_per_t}, "
      f"effective cost/t = {mkt.Effective_cost_per_t} "
      f"(x{round(mkt.Effective_cost_per_t/mkt.Static_cost_per_t,1)} penalty from low delivery)")
