"""Monte Carlo robustness for IGEMS.

Design follows the manuscript specification:
  400 structural draws, seed 42.
  hist_resp_coeff ~ U(0.20, 0.60)
  income-tier divisors varied +/- 15 percent
  forest_multiplier ~ U(1.5, 2.5)
  hybrid weights ~ Dirichlet(1,1,1)

For each draw we record, per mechanism: mean binary corridor adherence,
population-weighted mean acceptance, and per-capita max:min ratio.
"""

import numpy as np
import pandas as pd
from igems_model import run, MECHANISMS, BASE

N_DRAWS = 400
SEED = 42


def one_draw(rng):
    return dict(
        hist_resp_coeff=rng.uniform(0.20, 0.60),
        equity_dev_divisor=BASE["equity_dev_divisor"] * rng.uniform(0.85, 1.15),
        capacity_dev_divisor=BASE["capacity_dev_divisor"] * rng.uniform(0.85, 1.15),
        forest_multiplier=rng.uniform(1.5, 2.5),
        hybrid_weights=tuple(rng.dirichlet([1.0, 1.0, 1.0])),
    )


def main():
    rng = np.random.default_rng(SEED)
    rows = []
    for i in range(N_DRAWS):
        params = one_draw(rng)
        res, _ = run(params)
        pop = res["Population_millions"].values
        row = dict(draw=i, **{k: (v if not isinstance(v, tuple) else None)
                              for k, v in params.items()})
        row["w_market"], row["w_equity"], row["w_capacity"] = params["hybrid_weights"]
        for m in MECHANISMS:
            row[f"{m}_adherence"] = res[f"{m}_binary_corridor"].mean()
            row[f"{m}_accept_popw"] = float(
                (res[f"{m}_acceptance_propensity"] * pop).sum() / pop.sum())
            pc = res[f"{m}_per_capita_t"].values
            row[f"{m}_maxmin"] = pc.max() / pc.min()
        rows.append(row)
    mc = pd.DataFrame(rows).drop(columns=["hybrid_weights"])
    mc.to_csv("../outputs/monte_carlo_draws.csv", index=False)

    summary = []
    for m in MECHANISMS:
        a = mc[f"{m}_adherence"]
        summary.append(dict(
            Mechanism=m,
            adherence_mean=round(a.mean(), 3),
            adherence_p5=round(a.quantile(0.05), 3),
            adherence_p95=round(a.quantile(0.95), 3),
            accept_mean=round(mc[f"{m}_accept_popw"].mean(), 3),
            maxmin_median=round(mc[f"{m}_maxmin"].median(), 2),
            share_adherence_ge_040=round((a >= 0.40 - 1e-9).mean(), 3),
        ))
    s = pd.DataFrame(summary)
    s.to_csv("../outputs/monte_carlo_summary.csv", index=False)
    print(s.to_string(index=False))

    ranks = mc[[f"{m}_adherence" for m in MECHANISMS]].rank(axis=1, ascending=False, method="min")
    for m in MECHANISMS:
        top = (ranks[f"{m}_adherence"] == 1).mean()
        print(f"{m}: ranked first (incl. ties) in {top:.1%} of draws")
    print("Market last:", (ranks["Market_adherence"] == 4).mean())


if __name__ == "__main__":
    main()
