"""Robustness extensions requested at second review.

(A) Carbon-budget sensitivity: rerun at 420, 500, 580, 650 Gt cumulative
    (8.4, 10.0, 11.6, 13.0 Gt/yr over a 50-year horizon).
(B) Acceptance-slope sensitivity: vary the logistic slope in {4, 8, 12, 16}
    and confirm the rule ranking is invariant.
(C) Framework benchmark: add Equal Per Capita and a Contraction-and-
    Convergence endpoint as computed reference allocations alongside the
    four IGEMS rules.
"""

import numpy as np
import pandas as pd
from scipy.special import expit
from igems_model import (run, setup_regional_data, allocate_market,
                         allocate_equity, allocate_capacity, allocate_hybrid,
                         MECHANISMS, BASE)

CUMULATIVE = {420: 8.4, 500: 10.0, 580: 11.6, 650: 13.0}


def adherence_and_gridlock(res):
    out = {}
    high = res[res["Region_code"].isin(["NA", "EU", "CN", "JK", "RC"])]
    low = res[res["Region_code"].isin(["LA", "MENA", "ISA", "SSA"])]
    for m in MECHANISMS:
        adh = res[f"{m}_binary_corridor"].mean()
        he = float((high[f"{m}_acceptance_propensity"] * high["Population_millions"]).sum()
                   / high["Population_millions"].sum())
        li = float((low[f"{m}_acceptance_propensity"] * low["Population_millions"]).sum()
                   / low["Population_millions"].sum())
        out[m] = dict(adherence=round(adh, 3), high=round(he, 3), low=round(li, 3),
                      both=(he > 0.5 and li > 0.5))
    return out


# (A) Carbon-budget sensitivity ------------------------------------------
rows = []
for cum, yr in CUMULATIVE.items():
    res, _ = run({"global_budget_Gt": yr})
    a = adherence_and_gridlock(res)
    for m in MECHANISMS:
        rows.append(dict(Cumulative_Gt=cum, Annual_Gt=yr, Mechanism=m,
                         Adherence=a[m]["adherence"],
                         High_accept=a[m]["high"], Low_accept=a[m]["low"],
                         Both_participate="Yes" if a[m]["both"] else "No"))
budget = pd.DataFrame(rows)
budget.to_csv("../outputs/sensitivity_carbon_budget.csv", index=False)

print("=== (A) CARBON-BUDGET SENSITIVITY: mean adherence by rule ===")
piv = budget.pivot(index="Mechanism", columns="Cumulative_Gt", values="Adherence").loc[MECHANISMS]
print(piv.to_string())
print("\nGridlock persists (no rule clears both blocs) at every budget:",
      (budget["Both_participate"] == "No").all())
print("Market ranks last on adherence at every budget:",
      all(budget[budget.Cumulative_Gt == c].set_index("Mechanism")["Adherence"].idxmin() == "Market"
          for c in CUMULATIVE))

# (B) Slope sensitivity ---------------------------------------------------
res_base, _ = run()
cut = {m: np.clip((res_base["Current_emissions_Gt"].values
                   - res_base[f"{m}_allocation_Gt"].values)
                  / res_base["Current_emissions_Gt"].values, 0, 1)
       for m in MECHANISMS}
pop = res_base["Population_millions"].values
print("\n=== (B) ACCEPTANCE-SLOPE SENSITIVITY: pop-weighted mean acceptance ===")
srows = []
for slope in [4, 8, 12, 16]:
    line = {"slope": slope}
    for m in MECHANISMS:
        s = expit(slope * (0.5 - cut[m]))
        line[m] = round(float((s * pop).sum() / pop.sum()), 3)
    srows.append(line)
sl = pd.DataFrame(srows)
sl.to_csv("../outputs/sensitivity_slope.csv", index=False)
print(sl.to_string(index=False))
order = [tuple(pd.Series({m: r[m] for m in MECHANISMS}).sort_values(ascending=False).index)
         for r in srows]
print("Acceptance ordering identical across all slopes:", len(set(order)) == 1, order[0])

# (C) Framework benchmark: Equal Per Capita and C&C endpoint --------------
df = setup_regional_data()
B = 10.0
epc = df["Population_fraction"].values * B          # equal per capita
cc = epc.copy()                                     # C&C endpoint = equal per capita
res_base, _ = run()
bench = pd.DataFrame({
    "Region_code": df["Region_code"],
    "Current_Gt": df["Current_emissions_Gt"],
    "Market_Gt": allocate_market(df, BASE).round(3),
    "Equity_Gt": allocate_equity(df, BASE).round(3),
    "Capacity_Gt": allocate_capacity(df, BASE).round(3),
    "Hybrid_Gt": allocate_hybrid(df, BASE).round(3),
    "EqualPerCapita_Gt": epc.round(3),
    "ContractConverge_Gt": cc.round(3),
})
bench.to_csv("../outputs/framework_benchmark.csv", index=False)
print("\n=== (C) FRAMEWORK BENCHMARK (Gt/yr) ===")
print(bench.to_string(index=False))

# per-capita inequity ratio for EPC (should be 1.0 by construction)
epc_pc = epc / df["Population_millions"].values
print("\nEqual-per-capita ratio (max:min):", round(epc_pc.max() / epc_pc.min(), 2),
      "(=1.00 by construction; equity rule 1.64 is closest IGEMS rule)")
