"""Generate the five main-text figures for the GEC manuscript.

Figures use only workbook-verified base-case numbers plus the seeded
400-draw Monte Carlo (monte_carlo.py). 300 dpi PNG and PDF.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from igems_model import run, solidarity_fund, MECHANISMS

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 300, "savefig.bbox": "tight",
})

COLORS = {"Market": "#b2182b", "Equity": "#2166ac",
          "Capacity": "#1a9850", "Hybrid": "#e08214"}
FIGDIR = "../figures"

res, p = run()
mc = pd.read_csv("../outputs/monte_carlo_draws.csv")
regions = res["Region"].tolist()
codes = res["Region_code"].tolist()


def save(fig, name):
    fig.savefig(f"{FIGDIR}/{name}.png")
    fig.savefig(f"{FIGDIR}/{name}.pdf")
    plt.close(fig)


# Figure 1: mean binary adherence by rule with Monte Carlo spread
fig, ax = plt.subplots(figsize=(5.2, 3.4))
means = [res[f"{m}_binary_corridor"].mean() for m in MECHANISMS]
for i, m in enumerate(MECHANISMS):
    draws = mc[f"{m}_adherence"].values
    jitter = np.random.default_rng(1).normal(0, 0.055, len(draws))
    ax.scatter(i + jitter, draws, s=5, alpha=0.18, color=COLORS[m],
               edgecolors="none", zorder=1)
    ax.hlines(means[i], i - 0.28, i + 0.28, color=COLORS[m], lw=2.5, zorder=3)
    lo, hi = np.quantile(draws, [0.05, 0.95])
    ax.vlines(i, lo, hi, color=COLORS[m], lw=1.1, zorder=2)
ax.set_xticks(range(4), MECHANISMS)
ax.set_ylabel("Mean binary corridor adherence")
ax.set_ylim(0.1, 0.6)
ax.axhline(0.5, color="grey", lw=0.7, ls=":")
ax.text(3.45, 0.505, "half of regions\nwithin corridor", fontsize=7, color="grey", va="bottom")
save(fig, "fig1_adherence")

# Figure 2: bloc acceptance heatmap
bloc = pd.read_excel(
    "../data/IGEMS_coalition_outputs.xlsx", sheet_name="table4_blocs",
    keep_default_na=False)
mat = bloc[[f"{m}_Accept" for m in MECHANISMS]].values
fig, ax = plt.subplots(figsize=(5.2, 3.6))
im = ax.imshow(mat, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
ax.set_xticks(range(4), MECHANISMS)
labels = [f"{b} ({pct}%)" for b, pct in zip(bloc["Bloc"], bloc["Pop_%"])]
ax.set_yticks(range(len(bloc)), labels)
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        ax.text(j, i, f"{mat[i, j]:.2f}", ha="center", va="center",
                fontsize=8, color="black")
cb = fig.colorbar(im, ax=ax, shrink=0.85)
cb.set_label("Population-weighted acceptance")
save(fig, "fig2_bloc_heatmap")

# Figure 3: allocation vs current emissions, with negative reductions flagged
fig, ax = plt.subplots(figsize=(7.0, 3.6))
x = np.arange(9)
w = 0.19
ax.bar(x - 1.5 * w, res["Current_emissions_Gt"], w * 0.9, color="#4d4d4d",
       label="Current emissions (2024)")
for k, m in enumerate(MECHANISMS):
    ax.bar(x + (k - 0.5) * w, res[f"{m}_allocation_Gt"], w * 0.9,
           color=COLORS[m], label=f"{m} allocation")
for i in range(9):
    for k, m in enumerate(MECHANISMS):
        if res.loc[i, f"{m}_required_reduction_Gt"] < 0:
            ax.annotate("*", (x[i] + (k - 0.5) * w,
                        res.loc[i, f"{m}_allocation_Gt"] + 0.12),
                        ha="center", fontsize=10, color=COLORS[m])
ax.set_xticks(x, codes)
ax.set_ylabel("Gt CO$_2$ per year")
ax.legend(fontsize=7, ncol=5, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.12))
ax.text(0.99, 0.97, "* allocation exceeds current emissions\n(development surplus)",
        transform=ax.transAxes, ha="right", va="top", fontsize=7)
save(fig, "fig3_allocations")

# Figure 4: equity trade-off frontier (inequity vs adherence, acceptance size)
fig, ax = plt.subplots(figsize=(5.2, 3.6))
grid = {"Market": (0.182, 0.182), "Equity": (0.066, 0.875),
        "Capacity": (0.188, 0.534), "Hybrid": (0.140, 0.693)}
ratios = {"Market": 13.45, "Equity": 1.64, "Capacity": 37.90, "Hybrid": 4.81}
for m in MECHANISMS:
    adh = res[f"{m}_binary_corridor"].mean()
    ax.scatter(ratios[m], adh, s=1400 * grid[m][1] + 60, color=COLORS[m],
               alpha=0.75, edgecolors="black", lw=0.6, zorder=3)
    ax.annotate(m, (ratios[m], adh), xytext=(0, 14),
                textcoords="offset points", ha="center", fontsize=9)
ax.set_xscale("log")
ax.set_xlabel("Per-capita max:min allocation ratio (log scale)")
ax.set_ylabel("Mean binary corridor adherence")
ax.set_ylim(0.14, 0.54)
ax.text(0.02, 0.03, "Bubble size: lower-income bloc acceptance",
        transform=ax.transAxes, fontsize=7, color="grey")
save(fig, "fig4_tradeoff")

# Figure 5: Solidarity Fund flows, corrected USD units
fund, tot = solidarity_fund(res, carbon_price=100)
fund = fund.set_index("Region_code").loc[
    ["RC", "NA", "JK", "CN", "EU", "LA", "MENA", "SSA", "ISA"]].reset_index()
signed = np.where(fund["Type"] == "CONTRIBUTOR",
                  fund["Billion_USD"], -fund["Billion_USD"])
fig, ax = plt.subplots(figsize=(6.2, 3.4))
colors = ["#b2182b" if s > 0 else "#2166ac" for s in signed]
ax.bar(fund["Region_code"], signed, color=colors)
ax.axhline(0, color="black", lw=0.8)
for xi, s in enumerate(signed):
    ax.annotate(f"{abs(s):.0f}", (xi, s + (4 if s > 0 else -4)),
                ha="center", va="bottom" if s > 0 else "top", fontsize=8)
ax.set_ylabel("Billion USD per year (USD 100 per tonne)")
ax.set_ylim(-160, 80)
ax.text(0.01, 0.05,
        f"Total redistribution: {tot:.2f} Gt per year\n"
        f"USD {tot*75:.0f}-{tot*150:.0f} billion at USD 75-150 per tonne",
        transform=ax.transAxes, fontsize=8)
ax.text(0.99, 0.95, "Contributors (red) pay; recipients (blue) receive",
        transform=ax.transAxes, ha="right", fontsize=7, color="grey")
save(fig, "fig5_fund")

print("Figures written to", FIGDIR)
