"""IGEMS coalition allocation model.

Nine macro-regions, four allocation rules, corridor adherence,
acceptance propensity, bloc mapping, two-bloc gridlock test, and
Solidarity Fund arithmetic.

Reproduces IGEMS_coalition_outputs.xlsx exactly under base parameters.
The fund USD conversion is corrected here: 1 Gt x USD p/t = p billion USD.
"""

import numpy as np
import pandas as pd
from scipy.special import expit

MECHANISMS = ["Market", "Equity", "Capacity", "Hybrid"]

BASE = dict(
    global_budget_Gt=10.0,
    hist_resp_coeff=0.40,
    equity_dev_divisor=10.0,
    capacity_dev_divisor=30.0,
    forest_multiplier=2.0,
    hybrid_weights=(0.40, 0.35, 0.25),  # (market, equity, capacity)
    carbon_price=100.0,
)


def setup_regional_data():
    regions = {
        "Region": [
            "North America", "Europe", "China", "Japan & Korea",
            "Russia & Central Asia", "Latin America",
            "Middle East & N. Africa", "India & South Asia",
            "Sub-Saharan Africa",
        ],
        "Region_code": ["NA", "EU", "CN", "JK", "RC", "LA", "MENA", "ISA", "SSA"],
        "Current_emissions_Gt": [6.5, 3.8, 11.0, 1.4, 1.8, 1.5, 2.0, 3.0, 1.0],
        "Population_millions": [580, 450, 1420, 170, 280, 650, 400, 2200, 1200],
        "GDP_trillions_USD": [27.5, 17.2, 17.8, 4.2, 1.8, 5.5, 2.1, 4.0, 1.5],
        "Historical_emissions_Gt": [850, 620, 280, 95, 120, 45, 60, 35, 15],
        "Forest_cover_fraction": [0.30, 0.35, 0.23, 0.68, 0.47, 0.52, 0.02, 0.23, 0.29],
        "Development_tier": [1, 1, 2, 1, 2, 3, 2, 4, 4],
        "Negotiating_bloc": [
            "Umbrella Group", "Annex I", "Major Emitter", "Developed",
            "Umbrella Group", "ALBA/Progressive", "AOSIS/LDC",
            "LMDC/G77", "AOSIS/LDC",
        ],
    }
    df = pd.DataFrame(regions)
    df["Population_fraction"] = df["Population_millions"] / df["Population_millions"].sum()
    df["Emissions_fraction"] = df["Current_emissions_Gt"] / df["Current_emissions_Gt"].sum()
    df["GDP_fraction"] = df["GDP_trillions_USD"] / df["GDP_trillions_USD"].sum()
    df["GDP_per_capita_000USD"] = df["GDP_trillions_USD"] * 1000 / df["Population_millions"]
    df["Hist_emissions_fraction"] = df["Historical_emissions_Gt"] / df["Historical_emissions_Gt"].sum()
    return df


def allocate_market(df, p):
    return df["Emissions_fraction"].values * p["global_budget_Gt"]


def allocate_equity(df, p):
    B = p["global_budget_Gt"]
    base_pc = df["Population_fraction"].values * B
    hist_adj = df["Hist_emissions_fraction"].values * p["hist_resp_coeff"] * base_pc
    dev = 1.0 / (df["GDP_per_capita_000USD"].values / p["equity_dev_divisor"] + 1.0)
    dev = dev / dev.sum() * B * 0.15
    alloc = np.maximum(base_pc - hist_adj + dev, 0.05)
    return alloc * (B / alloc.sum())


def allocate_capacity(df, p):
    forest = np.minimum(df["Forest_cover_fraction"].values * p["forest_multiplier"], 1.0)
    dev = 1.0 / (df["GDP_per_capita_000USD"].values / p["capacity_dev_divisor"] + 1.0)
    combined = forest * dev
    return combined / combined.sum() * p["global_budget_Gt"]


def allocate_hybrid(df, p):
    wm, we, wc = p["hybrid_weights"]
    return (wm * allocate_market(df, p)
            + we * allocate_equity(df, p)
            + wc * allocate_capacity(df, p))


def compliance_metrics(df, allocs, p):
    res = df.copy()
    equal_pc = p["global_budget_Gt"] / res["Population_millions"].sum()
    for name, alloc in allocs.items():
        res[f"{name}_allocation_Gt"] = alloc
        red = res["Current_emissions_Gt"].values - alloc
        res[f"{name}_required_reduction_Gt"] = red
        res[f"{name}_required_reduction_percent"] = red / res["Current_emissions_Gt"].values * 100
        pc = alloc / res["Population_millions"].values
        res[f"{name}_per_capita_t"] = pc
        res[f"{name}_fairness_distance"] = np.abs(pc - equal_pc) / equal_pc
        cut = np.clip(red / res["Current_emissions_Gt"].values, 0, 1)
        res[f"{name}_acceptance_propensity"] = expit(8.0 * (0.5 - cut))
        res[f"{name}_binary_corridor"] = np.where(cut <= 0.5, 0.8, 0.2)
    return res


def per_capita_stats(res):
    total_pc = res["Current_emissions_Gt"].sum() / res["Population_millions"].sum()
    out = {}
    for m in MECHANISMS:
        pc = res[f"{m}_per_capita_t"].values
        justice = float(np.clip(100 * (1 - np.mean(np.abs(pc - total_pc) / total_pc)), 0, 100))
        out[m] = dict(max_to_min_ratio=round(pc.max() / pc.min(), 2),
                      mean_per_capita=round(pc.mean(), 3),
                      justice_index=round(justice, 1))
    return out


def bloc_acceptance(res):
    rows = []
    for bloc, sub in res.groupby("Negotiating_bloc"):
        pop = sub["Population_millions"].sum()
        row = dict(Bloc=bloc,
                   population_pct=round(pop / res["Population_millions"].sum() * 100, 1),
                   regions=", ".join(sub["Region_code"]))
        for m in MECHANISMS:
            w = (sub[f"{m}_acceptance_propensity"] * sub["Population_millions"]).sum() / pop
            row[f"{m}_accept"] = round(float(w), 3)
        rows.append(row)
    return pd.DataFrame(rows)


def gridlock(res, threshold=0.5):
    high = res[res["Region_code"].isin(["NA", "EU", "CN", "JK", "RC"])]
    low = res[res["Region_code"].isin(["LA", "MENA", "ISA", "SSA"])]
    rows = []
    for m in MECHANISMS:
        he = float((high[f"{m}_acceptance_propensity"] * high["Population_millions"]).sum()
                   / high["Population_millions"].sum())
        li = float((low[f"{m}_acceptance_propensity"] * low["Population_millions"]).sum()
                   / low["Population_millions"].sum())
        both = he > threshold and li > threshold
        rows.append(dict(Mechanism=m, HighEmit=round(he, 3), LowIncome=round(li, 3),
                         Both=both, Status="COALITION" if both else "GRIDLOCK"))
    return pd.DataFrame(rows)


def solidarity_fund(res, carbon_price):
    """Equal per-capita benchmark fund. USD conversion corrected:
    Gt x USD/t = billion USD (1 Gt = 1e9 t)."""
    B = res["Hybrid_allocation_Gt"].sum()
    bench = B / res["Population_millions"].sum() * res["Population_millions"].values
    gap = res["Hybrid_allocation_Gt"].values - bench
    fund = pd.DataFrame(dict(Region_code=res["Region_code"], Gap_Gt=gap))
    fund["Type"] = np.where(gap > 0, "CONTRIBUTOR", "RECIPIENT")
    fund["Flow_Gt"] = np.abs(gap)
    fund["Billion_USD"] = fund["Flow_Gt"] * carbon_price  # corrected units
    total_Gt = fund.loc[fund["Type"] == "RECIPIENT", "Flow_Gt"].sum()
    return fund.sort_values(["Type", "Flow_Gt"], ascending=[True, False]), total_Gt


def run(params=None):
    p = dict(BASE)
    if params:
        p.update(params)
    df = setup_regional_data()
    allocs = dict(Market=allocate_market(df, p), Equity=allocate_equity(df, p),
                  Capacity=allocate_capacity(df, p), Hybrid=allocate_hybrid(df, p))
    res = compliance_metrics(df, allocs, p)
    return res, p
