"""External validation of IGEMS against canonical effort-sharing categories.

The IPCC AR5/AR6 effort-sharing literature (Hoehne et al. 2014; van den
Berg et al. 2020; Robiou du Pont et al. 2017) organises fair-share
allocations into a small set of standard categories. We construct five of
them from the SAME public inputs used by IGEMS, then test whether each
IGEMS rule reproduces the category it claims to operationalise.

Categories (each allocates the 10 Gt/yr ceiling across the nine regions):
  GF   Grandfathering            A_i proportional to current emissions
  EPC  Equal per capita          A_i proportional to population
  ECPC Equal cumulative p.c.     population-based, debited by historical use
  AP   Ability to pay            cuts shared in proportion to GDP
  GDR  Greenhouse Dev. Rights    cuts shared by a responsibility-capability index

Validity is assessed by Spearman rank correlation across the nine regions
between each IGEMS allocation vector and each canonical category vector.
The pre-registered expectations are:
  IGEMS market  ~ GF        (grandfathering, by construction)
  IGEMS equity  ~ GDR, ECPC, EPC   (responsibility + capability + per capita)
  IGEMS capacity: no canonical analogue (ecological); reported honestly
  IGEMS hybrid  ~ GF/EPC blend
"""

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr
from igems_model import (setup_regional_data, allocate_market, allocate_equity,
                         allocate_capacity, allocate_hybrid, BASE, MECHANISMS)

B = 10.0
df = setup_regional_data()
E = df["Current_emissions_Gt"].values
P = df["Population_millions"].values
Y = df["GDP_trillions_USD"].values
H = df["Historical_emissions_Gt"].values
codes = df["Region_code"].values
total_reduction = E.sum() - B          # 22 Gt of cuts to distribute
gdp_pc = Y * 1000 / P                   # GDP per capita, thousand USD


def renorm(a):
    a = np.maximum(a, 0.01)
    return a / a.sum() * B


# ---- canonical categories -------------------------------------------------
def cat_GF():
    return renorm(E)                                   # current-emissions share


def cat_EPC():
    return renorm(P)                                   # population share


def cat_ECPC():
    # equal cumulative per capita: population entitlement over a long horizon,
    # debited by cumulative historical emissions already used.
    horizon_budget = B * 50 + H.sum()                  # future + already emitted
    entitlement = P / P.sum() * horizon_budget - H     # net remaining entitlement
    return renorm(np.maximum(entitlement, 0))


def cat_AP():
    # ability to pay: reduction burden proportional to GDP share
    red = total_reduction * (Y / Y.sum())
    return renorm(E - red)


def cat_GDR(dev_threshold_pc=9.0):
    # responsibility = share of cumulative historical emissions
    resp = H / H.sum()
    # capability = share of income above a development threshold (GDR logic)
    income_above = np.maximum(gdp_pc - dev_threshold_pc, 0) * P
    cap = income_above / income_above.sum()
    rci = 0.5 * resp + 0.5 * cap                        # responsibility-capability index
    rci = rci / rci.sum()
    red = total_reduction * rci
    return renorm(E - red)


CANON = {"GF": cat_GF(), "EPC": cat_EPC(), "ECPC": cat_ECPC(),
         "AP": cat_AP(), "GDR": cat_GDR()}

IGEMS = {"Market": allocate_market(df, BASE), "Equity": allocate_equity(df, BASE),
         "Capacity": allocate_capacity(df, BASE), "Hybrid": allocate_hybrid(df, BASE)}

# ---- correlation matrices -------------------------------------------------
sp_rows, pe_rows = [], []
for m in MECHANISMS:
    sp = {"IGEMS_rule": m}
    pe = {"IGEMS_rule": m}
    for c, vec in CANON.items():
        sp[c] = round(spearmanr(IGEMS[m], vec).correlation, 3)
        pe[c] = round(pearsonr(IGEMS[m], vec)[0], 3)
    sp_rows.append(sp)
    pe_rows.append(pe)
spear = pd.DataFrame(sp_rows)
pears = pd.DataFrame(pe_rows)
spear.to_csv("../outputs/validation_spearman.csv", index=False)
pears.to_csv("../outputs/validation_pearson.csv", index=False)

print("=== Spearman rank correlation: IGEMS rule vs canonical category ===")
print(spear.to_string(index=False))
print("\n=== Pearson correlation ===")
print(pears.to_string(index=False))

# ---- best-match summary ---------------------------------------------------
print("\n=== Best canonical match per IGEMS rule (Spearman) ===")
for _, r in spear.iterrows():
    vals = {c: r[c] for c in CANON}
    best = max(vals, key=vals.get)
    print(f"  {r['IGEMS_rule']:9s} -> {best:5s} (rho = {vals[best]:.3f})")

# ---- category allocations table -------------------------------------------
tab = pd.DataFrame({"Region": codes, "Current": E})
for c, vec in CANON.items():
    tab[c] = np.round(vec, 3)
tab.to_csv("../outputs/validation_categories.csv", index=False)
print("\n=== Canonical effort-sharing allocations (Gt/yr) ===")
print(tab.to_string(index=False))
